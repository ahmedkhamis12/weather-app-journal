
/* Global Variables */
let d = new Date();
// declare newDate variable to get fullDate
let newDate = d.getMonth()+1+'.'+ d.getDate()+'.'+ d.getFullYear();
//declare a personal api key
const myApiKey='1ecbd3b84a13633414f36fb0331a8a95';
//get the button id
const button=document.querySelector('#generate');
// declare async function when click on generate
button.addEventListener('click',async ()=>{
    //get the zipcode value
    const zipCode=document.querySelector('#zip').value;
    //checking if zipcode is not a number
    if(isNaN(zipCode)){
        return window.alert('please enter a number');
    }
    //checking if zipcode length is invalid
    if(zipCode.length!=5){
        return window.alert('invalid zip code');
    }
    
   

try{
    const url=`https://api.openweathermap.org/data/2.5/weather?zip=${zipCode}&appid=${myApiKey}&units=imperial`;
    //fetch url with a certain zipCode and apikey
    const resUrl=await fetch(url);
    //transform into json
    const allData=await resUrl.json();
    //get only temperature value from all data
    const currentTempData=allData.main.temp;
     //get the feeling value the user has typed
     const feelings=document.querySelector('#feelings').value
    //post data
    await fetch('/postWeatherData',{
        method:"POST",
        headers:{"Content-Type": "application/json"},
        body: JSON.stringify({
            date: newDate,
            temp: currentTempData,
            feelings: feelings

        })
    });

    // call function to retrieve weatherData
    retrieveData();
   
}catch(error){console.log(error);}
 
});
const retrieveData = async () =>{
    const request = await fetch('/getWeatherData');
    try {
    // Transform into JSON
    const allData = await request.json()
    console.log(allData)
    // Write updated data to DOM elements
    document.getElementById('temp').innerHTML = 'Temperature: '+Math.round(allData.temp)+ ' ℉ degrees';
    document.getElementById('content').innerHTML = 'Feeling:'+allData.feelings;
    document.getElementById("date").innerHTML ='Date: '+allData.date;
    }
    catch(error) {
      console.log("error", error);
      // appropriately handle the error
    }
   }
  
