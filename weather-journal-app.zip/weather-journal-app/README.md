# Weather-Journal App Project

# Project Description
a weather website to get a current temperature of a country by entering zipcode only  
## Overview
This project requires you to create an asynchronous web app that uses Web API and user data to dynamically update the UI. 

# How to Install and Run the Project
download the zip file then open the terminal and write npm install to downloadd all packages then write node server.js to run the server then open [http://localhost:3000](http://localhost:3000) to view it in your browser.
